# RIG
Random Inspiration Generator. Use it as much as you like, it stores what it generates in inspo.txt, have fun!
